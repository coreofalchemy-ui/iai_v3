/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
// This component is no longer used and has been removed.
// Image replacement functionality has been moved directly into the PreviewPanel
// for a more intuitive "in-preview" editing experience.
import React from 'react';

const ImageEditorPanel: React.FC = () => null;

export default ImageEditorPanel;
