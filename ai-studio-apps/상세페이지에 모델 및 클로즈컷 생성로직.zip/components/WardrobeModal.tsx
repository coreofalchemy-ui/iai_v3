/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';

const WardrobePanel: React.FC = () => null;

export default WardrobePanel;