/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
// This component is no longer used and has been removed.
// Its functionality has been integrated into AdjustmentPanel and PreviewPanel.
import React from 'react';

const RegenerationControls: React.FC = () => null;

export default RegenerationControls;
