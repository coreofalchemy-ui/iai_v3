/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';

// This component is no longer used and has been cleared.
const CropPanel: React.FC = () => null;

export default CropPanel;