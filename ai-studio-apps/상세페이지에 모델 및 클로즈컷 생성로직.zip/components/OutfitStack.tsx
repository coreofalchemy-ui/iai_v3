/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';

const OutfitStack: React.FC = () => null;

export default OutfitStack;