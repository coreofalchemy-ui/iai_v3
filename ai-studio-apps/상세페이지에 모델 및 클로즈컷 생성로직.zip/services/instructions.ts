

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

/**
 * @deprecated This file is no longer used. Custom instructions are now managed
 * and stored in the browser's localStorage via the UI in `App.tsx` and `InstructionsModal.tsx`.
 * This file is kept to avoid breaking potential old import paths but should not be used.
 */
export const PERMANENT_INSTRUCTIONS = '';