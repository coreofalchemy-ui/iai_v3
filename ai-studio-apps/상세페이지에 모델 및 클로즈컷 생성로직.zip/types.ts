/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

// This file is intentionally left blank as the previous types are no longer needed.
