/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';

const WardrobeModal: React.FC = () => {
    return null;
};

export default WardrobeModal;