/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

const CurrentOutfitPanel = () => null;
export default CurrentOutfitPanel;
