/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

const Footer = () => null;
export default Footer;
