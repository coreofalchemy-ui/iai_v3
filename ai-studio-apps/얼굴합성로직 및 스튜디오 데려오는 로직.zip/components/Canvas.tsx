/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

const Canvas = () => null;
export default Canvas;
