
export interface UploadFile {
  file: File;
  previewUrl: string;
}
